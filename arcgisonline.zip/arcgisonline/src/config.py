csvFilename = 'C:\\Users\\Martijn\\Documents\\GIS\\Scripts\\UpdateFeatureService\\export.CSV'

# Credentials and feature service information
username = "unilever_vreugdenhil"
password = "Martijn01"
service = "unilever.maps.arcgis.com"


fsURL = "http://services1.arcgis.com/gONaa3kS3EwdoWyG/arcgis/rest/services/export/FeatureServer"


